<?php 
ob_start();
session_start();
include 'islemler/baglan.php'; 

// Genel Ayarlar
$ayarsor=$db->prepare("SELECT * FROM ayar where ayar_id=:id");
$ayarsor->execute(array(
'id' => 0
));
$ayarcek=$ayarsor->fetch(PDO::FETCH_ASSOC);



// Hakkımda
$ayarsor2=$db->prepare("SELECT * FROM hakkimda where hakkimda_id=:ids");
$ayarsor2->execute(array(
'ids' => 0
));
$ayarcek2=$ayarsor2->fetch(PDO::FETCH_ASSOC);



// CV
$ayarsor3=$db->prepare("SELECT * FROM cv where cv_id=:idss");
$ayarsor3->execute(array(
'idss' => 0
));
$ayarcek3=$ayarsor3->fetch(PDO::FETCH_ASSOC);



// Servisler/Hizmetler
$ayarsor4=$db->prepare("SELECT * FROM servisler where servisler_id=:idsss");
$ayarsor4->execute(array(
'idsss' => 0
));
$ayarcek4=$ayarsor4->fetch(PDO::FETCH_ASSOC);



// İletişim / Footer
$ayarsor5=$db->prepare("SELECT * FROM iletisim_footer where aif_id=:idssss");
$ayarsor5->execute(array(
'idssss' => 0
));
$ayarcek5=$ayarsor5->fetch(PDO::FETCH_ASSOC);


// Admin

$adminsor=$db->prepare("SELECT * FROM admin where admin_kullaniciadi=:admin_kullaniciadi");
$adminsor->execute(array(
'admin_kullaniciadi' => $_SESSION['admin_kullaniciadi']
));
$say=$adminsor->rowCount();
$admincek=$adminsor->fetch(PDO::FETCH_ASSOC);

if ($say==0) {
	header("Location:index.php?izinsizgiris");
	exit();
}

?>

<!DOCTYPE html>
<html lang="tr">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="<?php $ayarcek['ayar_aciklama'] ?>">
	<meta name="author" content="<?php $ayarcek['ayar_author'] ?>">
	<meta name="keywords" content="<?php $ayarcek['ayar_keywords'] ?>">

	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link rel="shortcut icon" href="img/icons/icon-48x48.png" />

	<link rel="canonical" href="https://demo-basic.adminkit.io/" />

	<title>Admin Panel</title>

	<link href="css/app.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
</head>

<body>
	<div class="wrapper">
		<nav id="sidebar" class="sidebar js-sidebar">
			<div class="sidebar-content js-simplebar">
				<a class="sidebar-brand" href="">
          <span class="align-middle">A D M I N &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;P A N E L </span>
        </a>

				<ul class="sidebar-nav">
					<li class="sidebar-header">
						Panel Ayarları
					</li>

					<li class="sidebar-item active">
						<a class="sidebar-link" href="panel.php">
              <i class="align-middle" data-feather="home"></i> <span class="align-middle">Ana Sayfa</span>
            </a>
					</li>

					<li class="sidebar-item">
						<a class="sidebar-link" href="iletisimformu.php">
              <i class="align-middle" data-feather="clipboard"></i> <span class="align-middle">İletişim Formu</span>
            </a>
					</li>


					<li class="sidebar-header">
						Site Ayarları
					</li>


					<li class="sidebar-item">
						<a class="sidebar-link" href="hakkimda.php?durum">
              <i class="align-middle" data-feather="user"></i> <span class="align-middle">Hakkımda</span>
            </a>
					</li>

					<li class="sidebar-item">
						<a class="sidebar-link" href="cv.php?durum">
              <i class="align-middle" data-feather="grid"></i> <span class="align-middle">CV</span>
            </a>
					</li>

				

					<li class="sidebar-item">
						<a class="sidebar-link" href="hizmetler.php?durum">
              <i class="align-middle" data-feather="layers"></i> <span class="align-middle">Servis / Hizmetler</span>
            </a>
					</li>

						</li>

					<li class="sidebar-item">
						<a class="sidebar-link" href="footer-ayarlari.php?durum">
              <i class="align-middle" data-feather="calendar"></i> <span class="align-middle">Footer Ayarları</span>
            </a>
					</li>

					<li class="sidebar-header">
						Genel Ayarlar
					</li>

					<li class="sidebar-item">
						<a class="sidebar-link" href="site-ayarlari.php?durum">
              <i class="align-middle" data-feather="settings"></i> <span class="align-middle">Site Ayarları </span>
            </a>
					</li>

						<li class="sidebar-item">
						<a class="sidebar-link" href="sosyal-medya-ayarlari.php?durum">
              <i class="align-middle" data-feather="share-2"></i> <span class="align-middle">Sosyal Medya Ayarları</span>
            </a>
					</li>

						<li class="sidebar-item">
						<a class="sidebar-link" href="iletisim-ayarlari.php?durum">
              <i class="align-middle" data-feather="phone"></i> <span class="align-middle">İletişim Ayarları</span>
            </a>
					</li>

					
				

				
				</ul>

				
			</div>
		</nav>