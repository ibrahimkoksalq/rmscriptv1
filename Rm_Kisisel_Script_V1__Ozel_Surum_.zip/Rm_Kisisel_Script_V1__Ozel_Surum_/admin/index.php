<!DOCTYPE html>
<html lang="tr">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="İbrahim Köksal tarafından yapılan kişisel web site script'i">
	<meta name="author" content="İbrahim">
	<meta name="keywords" content="ibrahim köksal, rot media, kişisel web site script, kişisel template">

	<link rel="preconnect" href="https://fonts.gstatic.com">
	<link rel="shortcut icon" href="img/icons/icon-48x48.png" />

	<link rel="canonical" href="https://demo-basic.adminkit.io/pages-sign-in.html" />

	<title>Admin Panel Giriş Ekranı</title>

	<link href="css/app.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
</head>

<body>
	<main class="d-flex w-100">
		<div class="container d-flex flex-column">
			<div class="row vh-100">
				<div class="col-sm-10 col-md-8 col-lg-6 mx-auto d-table h-100">
					<div class="d-table-cell align-middle">

						<div class="text-center mt-4">
							<h1 class="h2">Hoşgeldin, Admin</h1>
							<p class="lead">
								Üyelik bilgileriniz ile giriş yapabilirsiniz.
							</p>
						</div>

						<div class="card">
							<div class="card-body">
								<div class="m-sm-4">
									<div class="text-center">
										<img src="img/avatars/avatar.jpg" alt="Charles Hall" class="img-fluid rounded-circle" width="132" height="132" />
									</div>
									<form action="islemler/islem.php" method="POST">
										<div class="mb-3">
											<label class="form-label">Kullanıcı Adınız</label>
											<input class="form-control form-control-lg" type="text" name="admin_kullaniciadi" placeholder="Admin hesabınızın kullanıcı adını giriniz..." />
										</div>
										<div class="mb-3">
											<label class="form-label">Şifreniz</label>
											<input class="form-control form-control-lg" type="password" name="admin_sifre" placeholder="Admin hesabınızın şifresini giriniz..." />
											
										</div>
									
										<div class="text-center mt-3">
										
											<button name="admingirisyap" type="submit" class="btn btn-lg btn-primary">Giriş Yap</button> 
										</div>
									</form>
								</div>
							</div>
						</div>

					</div>
				</div>
			</div>
		</div>
	</main>

	<script src="js/app.js"></script>

</body>

</html>