<?php 

try {
	$db=new PDO("mysql:host=localhost;dbname=yeniproje;charset=utf8", 'root', '111ibo111');
}
catch (PDDException $e) {
	echo $e->getMessage();
}

?>