<!DOCTYPE html>
<html>
<head>
	
	 <script type="text/javascript" src="sweetalert2.all.min.js"></script>

</head>
<body>

</body>
</html><?php 
ob_start();
session_start();
include 'baglan.php';



//İletişim Formu
if (isset($_POST['iletisimformugonder'])) {
	$gelen_adsoyad=$_POST['gelen_adsoyad'];
	$gelen_mail=$_POST['gelen_mail'];
	$gelen_konu=$_POST['gelen_konu'];
	$gelen_mesaj=$_POST['gelen_mesaj'];
	$gelen_ip = $_SERVER['REMOTE_ADDR'];
	}
 
 if ($db->query("INSERT INTO gelenmesajlar (gelen_adsoyad, gelen_mail, gelen_konu, gelen_mesaj, gelen_ip) VALUES ('$gelen_adsoyad','$gelen_mail','$gelen_konu','$gelen_mesaj', '$gelen_ip')")) 
        {
           if($_POST)
{
    echo '<script>Swal.fire("Başarılı", "Mesajınız bize ulaştı", "success"); </script>';
     header("Refresh: 2; url=../../index.php?formgonderildi");
}

        }
        else
        {
             header("Location:../index.php?hataolustu");
        }







// Admin Giriş

if (isset($_POST['admingirisyap'])) {
	$admin_kullaniciadi=$_POST['admin_kullaniciadi'];
	$admin_sifre=$_POST['admin_sifre'];

	$adminsor=$db->prepare("SELECT * FROM admin where admin_kullaniciadi=:admin_kullaniciadi and admin_sifre=:admin_sifre");
	$adminsor->execute(array(
		'admin_kullaniciadi' => $admin_kullaniciadi,
		'admin_sifre' => $admin_sifre
		));

	echo $say=$adminsor->rowCount();

	if ($say==1) {
		$_SESSION['admin_kullaniciadi']=$admin_kullaniciadi;
		header("Location:../panel.php");

	}
	else {

			header("Location:../index.php");

	}
}




// SİTE AYAR GUNCELLE

if (isset($_POST['genelayarkaydet'])) {
	$ayarkaydet=$db->prepare("UPDATE ayar SET
		ayar_title=:ayar_title,
		ayar_aciklama=:ayar_aciklama,
		ayar_keywords=:ayar_keywords,
		ayar_author=:ayar_author,
		ayar_yaptiklarim=:ayar_yaptiklarim
		WHERE ayar_id=0");


$update=$ayarkaydet->execute(array(
		'ayar_title' => $_POST['ayar_title'],
		'ayar_aciklama' => $_POST['ayar_aciklama'],
		'ayar_keywords' => $_POST['ayar_keywords'],
		'ayar_author' => $_POST['ayar_author'],
		'ayar_yaptiklarim' => $_POST['ayar_yaptiklarim']
		));

if ($update) {
	
	header('Location:../site-ayarlari.php?durum=ok');
}
else {

	header('Location:../site-ayarlari.php?durum=no');
}
}



// İLETİŞİM GÜNCELLEME


if (isset($_POST['iletisimayarkaydet'])) {
	$ayarkaydet=$db->prepare("UPDATE ayar SET
		ayar_telefon=:ayar_telefon,
		ayar_mail=:ayar_mail,
		ayar_adres=:ayar_adres		
		WHERE ayar_id=0");


$update=$ayarkaydet->execute(array(
		'ayar_telefon' => $_POST['ayar_telefon'],
		'ayar_mail' => $_POST['ayar_mail'],
		'ayar_adres' => $_POST['ayar_adres']
		));

if ($update) {
	
	header('Location:../iletisim-ayarlari.php?durum=ok');
}
else {

	header('Location:../iletisim-ayarlari.php?durum=no');
}
}






// SOSYAL MEDYA AYARLARI

if (isset($_POST['sosyalmedyaayarkaydet'])) {
	$ayarkaydet=$db->prepare("UPDATE ayar SET
		ayar_twitter=:ayar_twitter,
		ayar_facebook=:ayar_facebook,
		ayar_instagram=:ayar_instagram,
		ayar_linkedin=:ayar_linkedin,
		ayar_youtube=:ayar_youtube
		WHERE ayar_id=0");


$update=$ayarkaydet->execute(array(
		'ayar_twitter' => $_POST['ayar_twitter'],
		'ayar_facebook' => $_POST['ayar_facebook'],
		'ayar_instagram' => $_POST['ayar_instagram'],
		'ayar_linkedin' => $_POST['ayar_linkedin'],
		'ayar_youtube' => $_POST['ayar_youtube']
		));

if ($update) {
	
	header('Location:../sosyal-medya-ayarlari.php?durum=ok');
}
else {

	header('Location:../sosyal-medya-ayarlari.php?durum=no');
}
}



// HAKKIMDA AYARLARI


if (isset($_POST['hakkimdaayarkaydet'])) {
	$ayarkaydet=$db->prepare("UPDATE hakkimda SET
		hakkimda_yazi=:hakkimda_yazi,
		hakkimda_altbaslik=:hakkimda_altbaslik,
		hakkimda_altbaslik_yazi=:hakkimda_altbaslik_yazi,
		hakkimda_dogumtarihi=:hakkimda_dogumtarihi,
		hakkimda_website=:hakkimda_website,
		hakkimda_telefon=:hakkimda_telefon,
		hakkimda_city=:hakkimda_city,
		hakkimda_egitimdurumu=:hakkimda_egitimdurumu,
		hakkimda_mail=:hakkimda_mail,
		hakkimda_isdurumu=:hakkimda_isdurumu,
		hakkimda_ikialt_yazi=:hakkimda_ikialt_yazi
		WHERE hakkimda_id=0");


$update=$ayarkaydet->execute(array(
		'hakkimda_yazi' => $_POST['hakkimda_yazi'],
		'hakkimda_altbaslik' => $_POST['hakkimda_altbaslik'],
		'hakkimda_altbaslik_yazi' => $_POST['hakkimda_altbaslik_yazi'],
		'hakkimda_dogumtarihi' => $_POST['hakkimda_dogumtarihi'],
		'hakkimda_website' => $_POST['hakkimda_website'],
		'hakkimda_telefon' => $_POST['hakkimda_telefon'],
		'hakkimda_city' => $_POST['hakkimda_city'],
		'hakkimda_egitimdurumu' => $_POST['hakkimda_egitimdurumu'],
		'hakkimda_mail' => $_POST['hakkimda_mail'],
		'hakkimda_isdurumu' => $_POST['hakkimda_isdurumu'],
		'hakkimda_ikialt_yazi' => $_POST['hakkimda_ikialt_yazi']
		));

if ($update) {
	
	header('Location:../hakkimda.php?durum=ok');
}
else {

	header('Location:../hakkimda.php?durum=no');
}
}




// FOOTER ALANI GÜNCELLEME

if (isset($_POST['footerayarkaydet'])) {
	$ayarkaydet=$db->prepare("UPDATE iletisim_footer SET
		aif_footer_baslik=:aif_footer_baslik,
		aif_footer=:aif_footer
		WHERE aif_id=0");


$update=$ayarkaydet->execute(array(
		'aif_footer_baslik' => $_POST['aif_footer_baslik'],
		'aif_footer' => $_POST['aif_footer']
		));

if ($update) {
	
	header('Location:../footer-ayarlari.php?durum=ok');
}
else {

	header('Location:../footer-ayarlari.php?durum=no');
}
}




// SERVİSLER/HİZMETLER AYARLARI


if (isset($_POST['hizmetlerayarkaydet'])) {
	$ayarkaydet=$db->prepare("UPDATE servisler SET
		servisler_yazi=:servisler_yazi,
		servisler_bir_baslik=:servisler_bir_baslik,
		servisler_bir_yazi=:servisler_bir_yazi,
		servisler_iki_baslik=:servisler_iki_baslik,
		servisler_iki_yazi=:servisler_iki_yazi,
		servisler_uc_baslik=:servisler_uc_baslik,
		servisler_uc_yazi=:servisler_uc_yazi,
		servisler_dort_baslik=:servisler_dort_baslik,
		servisler_dort_yazi=:servisler_dort_yazi,
		servisler_bes_baslik=:servisler_bes_baslik,
		servisler_bes_yazi=:servisler_bes_yazi,
		servisler_alti_baslik=:servisler_alti_baslik,
		servisler_alti_yazi=:servisler_alti_yazi
		WHERE servisler_id=0");


$update=$ayarkaydet->execute(array(
		'servisler_yazi' => $_POST['servisler_yazi'],
		'servisler_bir_baslik' => $_POST['servisler_bir_baslik'],
		'servisler_bir_yazi' => $_POST['servisler_bir_yazi'],
		'servisler_iki_baslik' => $_POST['servisler_iki_baslik'],
		'servisler_iki_yazi' => $_POST['servisler_iki_yazi'],
		'servisler_uc_baslik' => $_POST['servisler_uc_baslik'],
		'servisler_uc_yazi' => $_POST['servisler_uc_yazi'],
		'servisler_dort_baslik' => $_POST['servisler_dort_baslik'],
		'servisler_dort_yazi' => $_POST['servisler_dort_yazi'],
		'servisler_bes_baslik' => $_POST['servisler_bes_baslik'],
		'servisler_bes_yazi' => $_POST['servisler_bes_yazi'],
		'servisler_alti_baslik' => $_POST['servisler_alti_baslik'],
		'servisler_alti_yazi' => $_POST['servisler_alti_yazi']
		));

if ($update) {
	
	header('Location:../hizmetler.php?durum=ok');
}
else {

	header('Location:../hizmetler.php?durum=no');
}
}





// CV AYARLARI


if (isset($_POST['cvayarkaydet'])) {
	$ayarkaydet=$db->prepare("UPDATE cv SET
		cv_yazi=:cv_yazi,
		cv_ilkokul_adi=:cv_ilkokul_adi,
		cv_ilkokul_yazi=:cv_ilkokul_yazi,
		cv_ortaokul_adi=:cv_ortaokul_adi,
		cv_ortaokul_yazi=:cv_ortaokul_yazi,
		cv_lise_adi=:cv_lise_adi,
		cv_lise_yazi=:cv_lise_yazi,
		cv_universite_adi=:cv_universite_adi,
		cv_universite_yazi=:cv_universite_yazi,
		cv_meslek_adi=:cv_meslek_adi,
		cv_meslek_yazi=:cv_meslek_yazi
		WHERE cv_id=0");


$update=$ayarkaydet->execute(array(
		'cv_yazi' => $_POST['cv_yazi'],
		'cv_ilkokul_adi' => $_POST['cv_ilkokul_adi'],
		'cv_ilkokul_yazi' => $_POST['cv_ilkokul_yazi'],
		'cv_ortaokul_adi' => $_POST['cv_ortaokul_adi'],
		'cv_ortaokul_yazi' => $_POST['cv_ortaokul_yazi'],
		'cv_lise_adi' => $_POST['cv_lise_adi'],
		'cv_lise_yazi' => $_POST['cv_lise_yazi'],
		'cv_universite_adi' => $_POST['cv_universite_adi'],
		'cv_universite_yazi' => $_POST['cv_universite_yazi'],
		'cv_meslek_adi' => $_POST['cv_meslek_adi'],
		'cv_meslek_yazi' => $_POST['cv_meslek_yazi']
		));

if ($update) {
	
	header('Location:../cv.php?durum=ok');
}
else {

	header('Location:../cv.php?durum=no');
}
}






?>