<?php include 'header.php'; //Menüler ?>


<div class="main">
			<nav class="navbar navbar-expand navbar-light navbar-bg">
				<a class="sidebar-toggle js-sidebar-toggle">
          <i class="hamburger align-self-center"></i>
        </a>

				<div class="navbar-collapse collapse">
					<ul class="navbar-nav navbar-align">
						<li class="nav-item dropdown">
							<a class="nav-icon dropdown-toggle" href="#" id="alertsDropdown" data-bs-toggle="dropdown">
								<div class="position-relative">
									<i class="align-middle" data-feather="bell"></i>
									<span class="indicator">1</span>
								</div>
							</a>
							<div class="dropdown-menu dropdown-menu-lg dropdown-menu-end py-0" aria-labelledby="alertsDropdown">
								<div class="dropdown-menu-header">
									1 Yeni Bildirim
								</div>
								<div class="list-group">
									
									<a href="#" class="list-group-item">
										<div class="row g-0 align-items-center">
											<div class="col-2">
												<i class="text-warning" data-feather="bell"></i>
											</div>
											<div class="col-10">
												<div class="text-dark">Hoşgeldiniz</div>
												<div class="text-muted small mt-1">Script'ı satın aldığınız için teşekkür ederim.</div>
												<div class="text-muted small mt-1">1 Dakika Önce</div>
											</div>
										</div>
									</a>
									
								
								</div>
								
							</div>
						</li>
						
						<li class="nav-item dropdown">
							<a class="nav-icon dropdown-toggle d-inline-block d-sm-none" href="#" data-bs-toggle="dropdown">
                <i class="align-middle" data-feather="settings"></i>
              </a>

							<a class="nav-link dropdown-toggle d-none d-sm-inline-block" href="#" data-bs-toggle="dropdown">
                <img src="img/avatars/avatar.jpg" class="avatar img-fluid rounded me-1" alt="Admin" /> <span class="text-dark">Merhaba, <b>Admin</b></span>
              </a>
							<div class="dropdown-menu dropdown-menu-end">
								<a class="dropdown-item" href="cikisyap.php"><i class="align-middle me-1" data-feather="log-out"></i> Çıkış Yap</a>
							</div>
						</li>
					</ul>
				</div>
			</nav>

			<main class="content">
				<div class="container-fluid p-0">

					<h1 class="h3 mb-3">Hoşgeldin,<strong> Admin</strong></h1>

					<div class="row">
						<div class="col-xl-12 col-xxl-12 d-flex">
							<div class="w-100">
								<div class="row">
									<div class="col-sm-12">
										<div class="card">
											<div class="card-body">
												<div class="row">
													<div class="col mt-0">
														<br><h5 class="card-title">ADMIN PANEL HAKKINDA ÖNEMLİ BİLGİLER</h5>
													</div>
													
												</div>
												<br>
												<div class="mb-0">
													<span class="text-danger"> <i class="mdi mdi-arrow-bottom-right"></i>Panel Ayarları</span><br>
													<span class="text-muted"><b>İletişim Formu:</b> Anasayfaki gelen iletişim verilerini bu alanda görebilirsiniz.</span>
												</div>
												<br>
													<div class="mb-0">
													<span class="text-danger"><i class="mdi mdi-arrow-bottom-right"></i>Site Ayarları</span><br>
													
												</div>

												<div class="mb-0">
													<span class="text-muted"><b>Hakkımda:</b> Sitenizde ki hakkımda sayfasındaki tüm içerklerini bu alandan düzenleyebilirsiniz.</span><br>
													<span class="text-muted"><b>CV:</b> Sitenizde CV alanını buradan düzenleyebilirsiniz.</span><br>
													<span class="text-muted"><b>Servis/Hizmetler:</b> Sitenizde servisler'e ait herşeyi buradan düzenleyebilirsiniz.</span><br>
													<span class="text-muted"><b>Footer Ayarları:</b> Sitenizdeki footer alanının buradan düzenleyebilirsiniz.</span>
												</div><br><br>

												<div class="mb-0">
													<span class="text-danger"> <i class="mdi mdi-arrow-bottom-right"></i>Genel Ayarlar</span><br>
													<span class="text-muted"><b>Site Ayarları:</b> Sitenizde genel ayarları buradan yapabilirsiniz.</span><br>
														<span class="text-muted"><b>Sosyal Medya Ayarları:</b> Sitenizde sosyal medya hesaplarını buradan yönetebilirsiniz.</span><br>
													<span class="text-muted"><b>İletişim Ayarları:</b> Sitenizde İletişim Ayarlarını buradan yapabilirsiniz.</span><br><br><br>Okuduğunuz İçin Teşekkürler,<br><b>İbrahim KÖKSAL</b>
												</div>
											</div>
										</div>
								
							
						
						
				
			</main>

		
		</div>
	</div>

	<script src="js/app.js"></script>



</body>

</html>