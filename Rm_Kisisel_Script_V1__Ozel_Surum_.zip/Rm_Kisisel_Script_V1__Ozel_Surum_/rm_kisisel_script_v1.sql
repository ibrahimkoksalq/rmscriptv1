-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 13 Ara 2022, 04:42:36
-- Sunucu sürümü: 10.4.27-MariaDB
-- PHP Sürümü: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `yeniproje`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `admin_kullaniciadi` varchar(100) NOT NULL,
  `admin_sifre` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Tablo döküm verisi `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_kullaniciadi`, `admin_sifre`) VALUES
(0, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ayar`
--

CREATE TABLE `ayar` (
  `ayar_id` int(11) NOT NULL,
  `ayar_title` varchar(300) NOT NULL,
  `ayar_aciklama` varchar(250) NOT NULL,
  `ayar_keywords` varchar(75) NOT NULL,
  `ayar_author` varchar(100) NOT NULL,
  `ayar_yaptiklarim` varchar(100) NOT NULL,
  `ayar_telefon` varchar(50) NOT NULL,
  `ayar_mail` varchar(60) NOT NULL,
  `ayar_adres` varchar(200) NOT NULL,
  `ayar_twitter` varchar(300) NOT NULL,
  `ayar_facebook` varchar(300) NOT NULL,
  `ayar_instagram` varchar(300) NOT NULL,
  `ayar_linkedin` varchar(300) NOT NULL,
  `ayar_youtube` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Tablo döküm verisi `ayar`
--

INSERT INTO `ayar` (`ayar_id`, `ayar_title`, `ayar_aciklama`, `ayar_keywords`, `ayar_author`, `ayar_yaptiklarim`, `ayar_telefon`, `ayar_mail`, `ayar_adres`, `ayar_twitter`, `ayar_facebook`, `ayar_instagram`, `ayar_linkedin`, `ayar_youtube`) VALUES
(0, 'RM Kişisel Site Script\'i V1', 'RM Kişisel Site Script\'i V1.0 Sürümü', 'kişisel script, kişisel template, kişisel site, rot media, rm kişisel blog ', 'İbrahim Köksal', 'Coder, Sosyal Medya Uzmanı, Grafik Tasarım', '0850 380 0096', 'info@rotmedia.com.tr', 'Mimarsinan, Atatürk Bulvarı, No: 260, 55200 Atakum/Samsun', 'https://www.twitter.com', 'https://www.facebook.com', 'https://www.instagram.com', 'https://www.linkedin.com', 'https://www.youtube.com');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `cv`
--

CREATE TABLE `cv` (
  `cv_id` int(11) NOT NULL,
  `cv_yazi` varchar(1000) NOT NULL,
  `cv_ilkokul_adi` varchar(150) NOT NULL,
  `cv_ilkokul_yazi` varchar(1000) NOT NULL,
  `cv_ortaokul_adi` varchar(150) NOT NULL,
  `cv_ortaokul_yazi` varchar(1000) NOT NULL,
  `cv_lise_adi` varchar(150) NOT NULL,
  `cv_lise_yazi` varchar(1000) NOT NULL,
  `cv_universite_adi` varchar(150) NOT NULL,
  `cv_universite_yazi` varchar(1000) NOT NULL,
  `cv_meslek_adi` varchar(100) NOT NULL,
  `cv_meslek_yazi` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Tablo döküm verisi `cv`
--

INSERT INTO `cv` (`cv_id`, `cv_yazi`, `cv_ilkokul_adi`, `cv_ilkokul_yazi`, `cv_ortaokul_adi`, `cv_ortaokul_yazi`, `cv_lise_adi`, `cv_lise_yazi`, `cv_universite_adi`, `cv_universite_yazi`, `cv_meslek_adi`, `cv_meslek_yazi`) VALUES
(0, 'Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir. Lorem Ipsum, adı bilinmeyen bir matbaacının bir hurufat numune kitabı oluşturmak üzere bir yazı galerisini alarak karıştırdığı 1500\'lerden beri endüstri standardı sahte metinler olarak kullanılmıştır.', 'İstanbul İlkokulu (2006-2010)', 'Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir. Lorem Ipsum, adı bilinmeyen bir matbaacının bir hurufat numune kitabı oluşturmak üzere bir yazı galerisini alarak karıştırdığı 1500\'lerden beri endüstri standardı sahte metinler olarak kullanılmıştır.', 'İstanbul Ortaokulu (2011-2015)', 'Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir. Lorem Ipsum, adı bilinmeyen bir matbaacının bir hurufat numune kitabı oluşturmak üzere bir yazı galerisini alarak karıştırdığı 1500\'lerden beri endüstri standardı sahte metinler olarak kullanılmıştır.', 'İstanbul Lise (2016-2020)', 'Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir. Lorem Ipsum, adı bilinmeyen bir matbaacının bir hurufat numune kitabı oluşturmak üzere bir yazı galerisini alarak karıştırdığı 1500\'lerden beri endüstri standardı sahte metinler olarak kullanılmıştır.', 'İstanbul Üniversite (2021 - Devam Ediyor)', 'Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir. Lorem Ipsum, adı bilinmeyen bir matbaacının bir hurufat numune kitabı oluşturmak üzere bir yazı galerisini alarak karıştırdığı 1500\'lerden beri endüstri standardı sahte metinler olarak kullanılmıştır.', 'Php Coder', '<br>Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir. Lorem Ipsum, adı bilinmeyen bir matbaacının bir hurufat numune kitabı oluşturmak üzere bir yazı galerisini alarak karıştırdığı 1500\'lerden beri endüstri standardı sahte metinler olarak kullanılmıştır.<br>Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir. Lorem Ipsum, adı bilinmeyen bir matbaacının bir hurufat numune kitabı oluşturmak üzere bir yazı galerisini alarak karıştırdığı 1500\'lerden beri endüstri standardı sahte metinler olarak kullanılmıştır.');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `gelenmesajlar`
--

CREATE TABLE `gelenmesajlar` (
  `gelen_id` int(11) NOT NULL,
  `gelen_adsoyad` varchar(50) NOT NULL,
  `gelen_mail` varchar(100) NOT NULL,
  `gelen_konu` varchar(200) NOT NULL,
  `gelen_mesaj` varchar(1000) NOT NULL,
  `gelen_ip` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `gelenmesajlar`
--

INSERT INTO `gelenmesajlar` (`gelen_id`, `gelen_adsoyad`, `gelen_mail`, `gelen_konu`, `gelen_mesaj`, `gelen_ip`) VALUES
(228, 'İbrahim', 'test@rotmedia.com.tr', 'Kişisel Script', 'Mesaj içerik', '::1');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `hakkimda`
--

CREATE TABLE `hakkimda` (
  `hakkimda_id` int(11) NOT NULL,
  `hakkimda_yazi` varchar(1000) NOT NULL,
  `hakkimda_altbaslik` varchar(100) NOT NULL,
  `hakkimda_altbaslik_yazi` varchar(350) NOT NULL,
  `hakkimda_resim` varchar(500) NOT NULL,
  `hakkimda_dogumtarihi` varchar(75) NOT NULL,
  `hakkimda_website` varchar(150) NOT NULL,
  `hakkimda_telefon` varchar(100) NOT NULL,
  `hakkimda_city` varchar(100) NOT NULL,
  `hakkimda_yas` varchar(100) NOT NULL,
  `hakkimda_egitimdurumu` varchar(100) NOT NULL,
  `hakkimda_mail` varchar(100) NOT NULL,
  `hakkimda_isdurumu` varchar(100) NOT NULL,
  `hakkimda_ikialt_yazi` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Tablo döküm verisi `hakkimda`
--

INSERT INTO `hakkimda` (`hakkimda_id`, `hakkimda_yazi`, `hakkimda_altbaslik`, `hakkimda_altbaslik_yazi`, `hakkimda_resim`, `hakkimda_dogumtarihi`, `hakkimda_website`, `hakkimda_telefon`, `hakkimda_city`, `hakkimda_yas`, `hakkimda_egitimdurumu`, `hakkimda_mail`, `hakkimda_isdurumu`, `hakkimda_ikialt_yazi`) VALUES
(0, 'Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir. Lorem Ipsum, adı bilinmeyen bir matbaacının bir hurufat numune kitabı oluşturmak üzere bir yazı galerisini alarak karıştırdığı 1500\'lerden beri endüstri standardı sahte metinler olarak kullanılmıştır.', 'PHP Coder & UI/UX Designer', 'Beşyüz yıl boyunca varlığını sürdürmekle kalmamış, aynı zamanda pek değişmeden elektronik dizgiye de sıçramıştır.', 'assets/img/profile-img.jpg', '1 Mayıs 2001', 'www.rotmedia.com.tr', '+90 555 555 5555', 'Samsun', '20', 'Üniversite', 'mail@siteadresi.com', 'Çalışıyor', 'Beşyüz yıl boyunca varlığını sürdürmekle kalmamış, aynı zamanda pek değişmeden elektronik dizgiye de sıçramıştır. Beşyüz yıl boyunca varlığını sürdürmekle kalmamış, aynı zamanda pek değişmeden elektronik dizgiye de sıçramıştır. Beşyüz yıl boyunca varlığını sürdürmekle kalmamış, aynı zamanda pek değişmeden elektronik dizgiye de sıçramıştır. Beşyüz yıl boyunca varlığını sürdürmekle kalmamış, aynı zamanda pek değişmeden elektronik dizgiye de sıçramıştır. Beşyüz yıl boyunca varlığını sürdürmekle kalmamış, aynı zamanda pek değişmeden elektronik dizgiye de sıçramıştır.');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `iletisim_footer`
--

CREATE TABLE `iletisim_footer` (
  `aif_id` int(11) NOT NULL,
  `aif_footer_baslik` varchar(500) NOT NULL,
  `aif_footer` varchar(350) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Tablo döküm verisi `iletisim_footer`
--

INSERT INTO `iletisim_footer` (`aif_id`, `aif_footer_baslik`, `aif_footer`) VALUES
(0, 'Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir.', 'Bu script <b>Rot Media</b> tarafından yapılmıştır.');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `servisler`
--

CREATE TABLE `servisler` (
  `servisler_id` int(11) NOT NULL,
  `servisler_yazi` varchar(1000) NOT NULL,
  `servisler_bir_baslik` varchar(50) NOT NULL,
  `servisler_bir_yazi` varchar(300) NOT NULL,
  `servisler_iki_baslik` varchar(50) NOT NULL,
  `servisler_iki_yazi` varchar(300) NOT NULL,
  `servisler_uc_baslik` varchar(50) NOT NULL,
  `servisler_uc_yazi` varchar(300) NOT NULL,
  `servisler_dort_baslik` varchar(50) NOT NULL,
  `servisler_dort_yazi` varchar(300) NOT NULL,
  `servisler_bes_baslik` varchar(50) NOT NULL,
  `servisler_bes_yazi` varchar(300) NOT NULL,
  `servisler_alti_baslik` varchar(50) NOT NULL,
  `servisler_alti_yazi` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Tablo döküm verisi `servisler`
--

INSERT INTO `servisler` (`servisler_id`, `servisler_yazi`, `servisler_bir_baslik`, `servisler_bir_yazi`, `servisler_iki_baslik`, `servisler_iki_yazi`, `servisler_uc_baslik`, `servisler_uc_yazi`, `servisler_dort_baslik`, `servisler_dort_yazi`, `servisler_bes_baslik`, `servisler_bes_yazi`, `servisler_alti_baslik`, `servisler_alti_yazi`) VALUES
(0, 'Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir. Lorem Ipsum, adı bilinmeyen bir matbaacının bir hurufat numune kitabı oluşturmak üzere bir yazı galerisini alarak karıştırdığı 1500\'lerden beri endüstri standardı sahte metinler olarak kullanılmıştır.', 'Web Tasarım', 'Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir.', 'Grafik Tasarım', 'Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir.', 'Seo Danışmanlığı', 'Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir.', 'E-Ticaret Danışmanlığı', 'Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir.', 'Reklam Danışmanlığı', 'Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir.', 'Marka Danışmanlığı', 'Lorem Ipsum, dizgi ve baskı endüstrisinde kullanılan mıgır metinlerdir.');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Tablo için indeksler `ayar`
--
ALTER TABLE `ayar`
  ADD PRIMARY KEY (`ayar_id`);

--
-- Tablo için indeksler `cv`
--
ALTER TABLE `cv`
  ADD PRIMARY KEY (`cv_id`);

--
-- Tablo için indeksler `gelenmesajlar`
--
ALTER TABLE `gelenmesajlar`
  ADD PRIMARY KEY (`gelen_id`);

--
-- Tablo için indeksler `hakkimda`
--
ALTER TABLE `hakkimda`
  ADD PRIMARY KEY (`hakkimda_id`);

--
-- Tablo için indeksler `iletisim_footer`
--
ALTER TABLE `iletisim_footer`
  ADD PRIMARY KEY (`aif_id`);

--
-- Tablo için indeksler `servisler`
--
ALTER TABLE `servisler`
  ADD PRIMARY KEY (`servisler_id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `gelenmesajlar`
--
ALTER TABLE `gelenmesajlar`
  MODIFY `gelen_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=231;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
